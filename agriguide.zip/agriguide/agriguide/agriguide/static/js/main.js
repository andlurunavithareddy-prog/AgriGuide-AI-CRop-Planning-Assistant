// ─────────────────────────────────────────────────
// AgriGuide — main.js
// ─────────────────────────────────────────────────

// ── State ──
let messageHistory = [];   // Full conversation history for Claude
let farmContext    = {};    // Farm details from sidebar form
let allCrops       = [];    // Loaded from /crops endpoint
let currentCrop    = null;  // Currently selected crop card


// ─────────────────────────────────────────────────
// INIT — Load crops on page load
// ─────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  loadCrops();
});


// ─────────────────────────────────────────────────
// LOAD CROPS from Flask /crops endpoint
// ─────────────────────────────────────────────────
async function loadCrops() {
  try {
    const res = await fetch("/crops");
    const data = await res.json();
    allCrops = data.crops;
    renderCropGrid(allCrops);
  } catch (err) {
    document.getElementById("crop-grid").innerHTML =
      '<p style="color:#f87171;font-size:12px">Failed to load crops.</p>';
  }
}

function renderCropGrid(crops) {
  const grid = document.getElementById("crop-grid");
  grid.innerHTML = crops.map(crop => `
    <div class="crop-card" onclick="selectCrop('${crop.name}')" id="card-${crop.name.replace(/\s/g,'-')}">
      <span class="crop-icon">${crop.icon}</span>
      <span class="crop-name">${crop.name}</span>
    </div>
  `).join("");
}


// ─────────────────────────────────────────────────
// SELECT CROP — Show detail card
// ─────────────────────────────────────────────────
function selectCrop(cropName) {
  const crop = allCrops.find(c => c.name === cropName);
  if (!crop) return;

  // Highlight selected card
  document.querySelectorAll(".crop-card").forEach(c => c.classList.remove("active"));
  const cardId = "card-" + cropName.replace(/\s/g, "-");
  document.getElementById(cardId)?.classList.add("active");

  currentCrop = crop;

  // Show detail panel
  const detail = document.getElementById("crop-detail");
  detail.classList.remove("hidden");

  document.getElementById("detail-icon").textContent = crop.icon;
  document.getElementById("detail-name").textContent = crop.name;

  const pestsHtml = crop.common_pests
    .map(p => `<span class="pest-tag">${p}</span>`)
    .join("");

  document.getElementById("detail-body").innerHTML = `
    <div class="detail-row"><span class="detail-label">🗓️ Season:</span><span class="detail-val">${crop.season}</span></div>
    <div class="detail-row"><span class="detail-label">💧 Water:</span><span class="detail-val">${crop.water}</span></div>
    <div class="detail-row"><span class="detail-label">⏳ Harvest:</span><span class="detail-val">${crop.days_to_harvest} days</span></div>
    <div class="detail-row"><span class="detail-label">🌡️ Temp:</span><span class="detail-val">${crop.temp_range}</span></div>
    <div class="detail-row"><span class="detail-label">📏 Spacing:</span><span class="detail-val">${crop.spacing}</span></div>
    <div class="detail-row"><span class="detail-label">🧪 Fertilizer:</span><span class="detail-val">${crop.fertilizer}</span></div>
    <div class="detail-row"><span class="detail-label">🪨 Soil:</span><span class="detail-val">${crop.soil}</span></div>
    <div class="detail-row"><span class="detail-label">⚠️ Pests:</span><span class="detail-val">${pestsHtml}</span></div>
    <div class="detail-row" style="margin-top:6px"><span class="detail-label">💡 Tip:</span><span class="detail-val" style="color:#d4a017">${crop.tips}</span></div>
  `;

  // Update ask button
  document.getElementById("btn-ask-crop").onclick = () => {
    askQuestion(`Give me a complete growing guide for ${crop.name}. Include sowing, irrigation, fertilizer schedule, pest management, and harvesting tips.`);
  };
}


// ─────────────────────────────────────────────────
// FARM CONTEXT — Save form values
// ─────────────────────────────────────────────────
function saveFarmContext() {
  farmContext = {
    location:     document.getElementById("location").value.trim(),
    soil_type:    document.getElementById("soil_type").value,
    acreage:      document.getElementById("acreage").value,
    season:       document.getElementById("season").value,
    water_source: document.getElementById("water_source").value,
  };

  const saved = document.getElementById("context-saved");
  saved.classList.remove("hidden");
  setTimeout(() => saved.classList.add("hidden"), 2500);
}


// ─────────────────────────────────────────────────
// QUICK QUESTION shortcut
// ─────────────────────────────────────────────────
function askQuestion(text) {
  document.getElementById("user-input").value = text;
  sendMessage();
  // Scroll chat into view on mobile
  document.querySelector(".chat-container").scrollIntoView({ behavior: "smooth" });
}


// ─────────────────────────────────────────────────
// SEND MESSAGE — Core chat function
// ─────────────────────────────────────────────────
async function sendMessage() {
  const input   = document.getElementById("user-input");
  const sendBtn = document.getElementById("send-btn");
  const text    = input.value.trim();

  if (!text) return;

  // Add user message to UI
  appendMessage("user", text);

  // Add to history for Claude
  messageHistory.push({ role: "user", content: text });

  // Clear input & disable button
  input.value = "";
  sendBtn.disabled = true;

  // Show typing indicator
  const typingId = showTyping();

  try {
    const res = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: messageHistory,
        farm_context: farmContext,
      }),
    });

    const data = await res.json();
    removeTyping(typingId);

    if (data.status === "success") {
      appendMessage("bot", data.reply);
      messageHistory.push({ role: "assistant", content: data.reply });
    } else {
      appendMessage("bot", "⚠️ " + (data.error || "Something went wrong. Please try again."));
    }

  } catch (err) {
    removeTyping(typingId);
    appendMessage("bot", "⚠️ Could not connect to server. Make sure Flask is running on port 5000.");
  }

  sendBtn.disabled = false;
  input.focus();
}


// ─────────────────────────────────────────────────
// APPEND MESSAGE to chat UI
// ─────────────────────────────────────────────────
function appendMessage(role, text) {
  const messages = document.getElementById("messages");

  const wrapper = document.createElement("div");
  wrapper.className = `message ${role === "user" ? "user-message" : "bot-message"}`;

  const avatar = document.createElement("div");
  avatar.className = `avatar ${role === "user" ? "user-avatar" : "bot-avatar"}`;
  avatar.textContent = role === "user" ? "👨‍🌾" : "🌿";

  const bubble = document.createElement("div");
  bubble.className = `bubble ${role === "user" ? "user-bubble" : "bot-bubble"}`;
  bubble.innerHTML = formatText(text);

  wrapper.appendChild(avatar);
  wrapper.appendChild(bubble);
  messages.appendChild(wrapper);

  // Scroll to bottom
  messages.scrollTop = messages.scrollHeight;
}


// ─────────────────────────────────────────────────
// FORMAT TEXT — Convert markdown-like syntax to HTML
// ─────────────────────────────────────────────────
function formatText(text) {
  return text
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/^### (.+)$/gm, "<h4 style='color:#74c69d;margin:10px 0 4px;font-size:13px'>$1</h4>")
    .replace(/^## (.+)$/gm,  "<h3 style='color:#95d5b2;margin:12px 0 6px;font-family:var(--font-title)'>$1</h3>")
    .replace(/^# (.+)$/gm,   "<h2 style='color:#d8f3dc;margin:12px 0 6px;font-family:var(--font-title)'>$1</h2>")
    .replace(/^- (.+)$/gm,   "<div style='display:flex;gap:8px;margin:3px 0'><span style='color:#52b788'>▸</span><span>$1</span></div>")
    .replace(/^\d+\. (.+)$/gm, (match, p1, offset, str) => {
      const num = match.match(/^(\d+)/)[1];
      return `<div style='display:flex;gap:8px;margin:4px 0'><span style='color:#52b788;min-width:18px'>${num}.</span><span>${p1}</span></div>`;
    })
    .replace(/\n\n/g, "<br/><br/>")
    .replace(/\n/g, "<br/>");
}


// ─────────────────────────────────────────────────
// TYPING INDICATOR
// ─────────────────────────────────────────────────
function showTyping() {
  const messages = document.getElementById("messages");
  const id = "typing-" + Date.now();

  const wrapper = document.createElement("div");
  wrapper.className = "message bot-message";
  wrapper.id = id;

  const avatar = document.createElement("div");
  avatar.className = "avatar bot-avatar";
  avatar.textContent = "🌿";

  const bubble = document.createElement("div");
  bubble.className = "bubble bot-bubble";
  bubble.innerHTML = `
    <div class="typing-indicator">
      <span></span><span></span><span></span>
    </div>`;

  wrapper.appendChild(avatar);
  wrapper.appendChild(bubble);
  messages.appendChild(wrapper);
  messages.scrollTop = messages.scrollHeight;

  return id;
}

function removeTyping(id) {
  document.getElementById(id)?.remove();
}


// ─────────────────────────────────────────────────
// CLEAR CHAT
// ─────────────────────────────────────────────────
function clearChat() {
  messageHistory = [];
  const messages = document.getElementById("messages");
  messages.innerHTML = `
    <div class="message bot-message">
      <div class="avatar bot-avatar">🌿</div>
      <div class="bubble bot-bubble">
        <p>Chat cleared! I'm ready to help with your farming questions. 🌱</p>
      </div>
    </div>`;
}


// ─────────────────────────────────────────────────
// KEYBOARD — Send on Enter, newline on Shift+Enter
// ─────────────────────────────────────────────────
function handleKeyDown(event) {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
}
