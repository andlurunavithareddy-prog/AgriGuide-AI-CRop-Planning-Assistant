from flask import Flask, render_template, request, jsonify
import json
import os
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)

# OpenRouter API Key
API_KEY = os.getenv("OPENROUTER_API_KEY")


# System prompt for AgriGuide AI
SYSTEM_PROMPT = """You are AgriGuide, an expert agricultural advisor with deep knowledge of:
- Crop science and agronomy
- Soil health and management
- Pest and disease control
- Irrigation and water management
- Fertilizer application and timing
- Seasonal crop planning
- Sustainable and organic farming practices
- Market-aware farming decisions

Your responses should be:
- Practical and actionable with specific steps
- Tailored to the farmer's context (soil, climate, season, resources)
- Include both traditional and modern farming practices
- Mention specific quantities, timings, and measurements
- Warn about common mistakes and risks
- Economically sensible for small to mid-scale farmers
- Easy to understand (avoid too much jargon)

Format your responses clearly with sections when needed. Be encouraging and empathetic — farming is hard work!"""


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/crops", methods=["GET"])
def get_crops():
    try:
        with open("config/crops.json", "r") as f:
            crops = json.load(f)
        return jsonify(crops)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/chat", methods=["POST"])
def chat():
    """Handle chat messages and call OpenRouter API"""

    try:
        data = request.get_json()

        messages = data.get("messages", [])
        farm_context = data.get("farm_context", {})

        # Build farm context
        context_parts = []

        if farm_context.get("location"):
            context_parts.append(f"Location: {farm_context['location']}")

        if farm_context.get("soil_type"):
            context_parts.append(f"Soil Type: {farm_context['soil_type']}")

        if farm_context.get("acreage"):
            context_parts.append(f"Farm Size: {farm_context['acreage']} acres")

        if farm_context.get("season"):
            context_parts.append(f"Current Season: {farm_context['season']}")

        if farm_context.get("water_source"):
            context_parts.append(f"Water Source: {farm_context['water_source']}")

        # Combine system + context
        system = SYSTEM_PROMPT

        if context_parts:
            system += "\n\nFarmer Context:\n" + "\n".join(context_parts)

        # Convert chat history
        conversation = system + "\n\nConversation:\n"

        for msg in messages:
            role = msg.get("role")
            content = msg.get("content")

            if role == "user":
                conversation += f"Farmer: {content}\n"
            else:
                conversation += f"AgriGuide: {content}\n"


        # Call OpenRouter API
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json",
                "HTTP-Referer": "http://localhost:5000",
                "X-Title": "AgriGuide"
            },
            json={
                "model": "deepseek/deepseek-chat",
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": conversation}
                ],
                "temperature": 0.7
            }
        )

        result = response.json()

        print("DEBUG RESPONSE:", result)


        # Extract AI reply safely
        if "choices" in result:
            reply = result["choices"][0]["message"]["content"]
        elif "error" in result:
            reply = "API Error: " + result["error"]["message"]
        else:
            reply = "AI service temporarily unavailable."

        return jsonify({
            "reply": reply,
            "status": "success"
        })


    except Exception as e:
        return jsonify({
            "error": f"Something went wrong: {str(e)}",
            "status": "error"
        }), 500


# ─────────────────────────────────────────────
# RUN SERVER
# ─────────────────────────────────────────────

if __name__ == "__main__":

    if not os.getenv("OPENROUTER_API_KEY"):
        print("⚠️ OPENROUTER_API_KEY not found in .env file")
        print("Create .env file and add:")
        print("OPENROUTER_API_KEY=your_key_here")
    else:
        print("✅ API Key loaded successfully")

    print("🌱 Starting AgriGuide server...")
    print("🌐 Open http://localhost:5000")

    app.run(debug=True, port=5000)