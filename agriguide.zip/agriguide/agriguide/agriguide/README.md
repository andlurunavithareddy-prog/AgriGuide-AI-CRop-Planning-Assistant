# 🌱 AgriGuide — AI Crop Planning & Advisory Tool

An AI-powered web application that helps farmers decide what to grow and how to manage their crops.

---

## 🛠️ Tech Stack

| Layer    | Technology         |
|----------|--------------------|
| Frontend | HTML, CSS, Vanilla JS |
| Backend  | Python + Flask     |
| AI       | Anthropic Claude API |
| Data     | JSON (crops.json)  |

---

## 📁 Project Structure

```
agriguide/
├── app.py                 ← Flask backend
├── requirements.txt       ← Python packages
├── .env                   ← Your API key (secret!)
├── .env.example           ← Template for .env
├── .gitignore
├── README.md
│
├── templates/
│   └── index.html         ← Main frontend page
│
├── static/
│   ├── css/style.css      ← Styling
│   └── js/main.js         ← Frontend logic
│
└── config/
    └── crops.json         ← Crop database
```

---

## 🚀 How to Run (Step by Step)

### Step 1 — Install Python
Make sure Python 3.10+ is installed:
```
python --version
```

### Step 2 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 3 — Set up your API key
Copy the example env file:
```bash
cp .env.example .env
```
Open `.env` and replace `your_api_key_here` with your actual key from https://console.anthropic.com

### Step 4 — Run the server
```bash
python app.py
```

### Step 5 — Open in browser
Visit: **http://localhost:5000**

---

## ✨ Features

- 💬 **AI Chat** — Ask any farming question, get expert advice
- 🚜 **Farm Context** — Personalize advice by entering your location, soil, season
- 🌾 **Crop Library** — Browse 10 crops with detailed growing info
- ⚡ **Quick Questions** — One-click common farming queries
- 📱 **Responsive** — Works on mobile and desktop

---

## 🔒 Security Note
- Your API key is stored in `.env` and **never exposed to the browser**
- `.env` is listed in `.gitignore` — it will NOT be uploaded to GitHub
